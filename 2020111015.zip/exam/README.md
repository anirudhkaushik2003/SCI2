Run python3 exam2.py to get the potential energies, to get the points uncomment line 20 in exam2.py
part1 and part2 done
not enough time for part3
