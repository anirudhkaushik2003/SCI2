import exam
import numpy as np
from mpl_toolkits import mplot3d
import numpy as np
import matplotlib.pyplot as plt
fig = plt.figure()
ax = plt.axes(projection='3d')

(point1,point2,point3,point4) = exam.make_point()
x= np.array([point1[0],point2[0],point3[0],point4[0]])
y= np.array([point1[1],point2[1],point3[1],point4[1]])
z= np.array([point1[2],point2[2],point3[2],point4[2]])

# Creating plot
ax.scatter3D(x, y, z, color = "blue")
plt.title("simple 3D scatter plot")
 
# show plot
plt.show()
#print(point1,point2,point3,point4)

point1=np.array(point1)
point2=np.array(point2)
point3=np.array(point3)
point4=np.array(point4)



epsilon= 0.238
sigma = 3.4

# 1 2
a = abs(np.subtract(point2,point1))
res = a[0]**2 + a[1]**2 + a[2]**2
res = res**0.5

final1 = 4*epsilon*((sigma/res)**12 - (sigma/res)**6)

# 1 3
a = abs(np.subtract(point1,point3))
res = a[0]**2 + a[1]**2 + a[2]**2
res = res**0.5

final2 = 4*epsilon*((sigma/res)**12 - (sigma/res)**6)



# 1 4
a = abs(np.subtract(point1,point4))
res = a[0]**2 + a[1]**2 + a[2]**2
res = res**0.5

final3 = 4*epsilon*((sigma/res)**12 - (sigma/res)**6)


# 2 3
a = abs(np.subtract(point2,point3))
res = a[0]**2 + a[1]**2 + a[2]**2
res = res**0.5
print("res = ",res)

final4 = 4*epsilon*((sigma/res)**12 - (sigma/res)**6)


# 2 4 
a = abs(np.subtract(point2,point4))
res = a[0]**2 + a[1]**2 + a[2]**2
res = res**0.5

final5 = 4*epsilon*((sigma/res)**12 - (sigma/res)**6)


# 3 4
a = abs(np.subtract(point3,point4))
res = a[0]**2 + a[1]**2 + a[2]**2
res = res**0.5

final6 = 4*epsilon*((sigma/res)**12 - (sigma/res)**6)

print("Final potential energies = ")
print(final1)
print(final2)
print(final3)
print(final4)
print(final5)
print(final6)


