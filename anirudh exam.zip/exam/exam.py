import random
import matplotlib.pyplot as plt
from scipy.special import factorial
import numpy as np

# random points
def make_point():
    point1 = [0,0,0]

    value = 5/(2**0.5)
    value2 = 6/(2**0.5)
    x=0
    y=0
    z=0

    x=random.uniform(0,value)
    y=random.uniform(0,value)
    z=(value2**2 - x**2 - y**2)**0.5

    x1=x
    y1=y
    z1=z

    point2=[x,y,z]

    x = x/2
    y = y/2
    z = z/2
    z+=3
    y+=3
    x+=3

    point3=[x,y,z]

    point4=[-1*x,-1*y,-1*z]
    
    return(point1,point2,point3,point4)
    





